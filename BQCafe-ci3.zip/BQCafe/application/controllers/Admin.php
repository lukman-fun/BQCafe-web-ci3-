<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	
	function __construct(){
	 parent::__construct();
	 $this->load->library("bqc");
	 $this->load->library("pdf");
	 $this->load->library("Excel/phpexcel","excel");
	 $this->load->model("M_Bqc");
	}
	
	
	
	public function index(){
	 $data["menu"]=$this->M_Bqc->dashboard("menu");
	 $data["room"]=$this->M_Bqc->dashboard("room");
	 $data["grafik"]=$this->M_Bqc->dashboard("grafik");
	 $data["data_grafik"]=$this->M_Bqc->grafik()->result();
	 $this->bqc->view("dashboard",$data);
	}
	
	//Transaksi
	public function transaksi(){
	 $data["menu"]=$this->M_Bqc->transaksi("menu")->result();
	 $data["room"]=$this->M_Bqc->transaksi("room")->result();
	 if($this->M_Bqc->transaksi("kode")->num_rows()>0){
	 $kode=(int)substr($this->M_Bqc->transaksi("kode")->row()->nota,8,12);
	 $data["kode"]="BQ".date("ymd").sprintf("%05s",$kode+1);
	 }else{
	 $data["kode"]="BQ".date("ymd")."00001";
	 }
	 $this->bqc->view("transaksi",$data);
	}
	

	
	public function addTransaksi(){
	//variabel menu
	$nota=$this->input->post("nota");
	$tgl=$this->input->post("tanggal");
	$ppn=$this->input->post("ppn");
	$total=$this->input->post("grandtotal");
	$potongan=$this->input->post("potongan");
	$bayar=$this->input->post("bayar");
	$kembalian=$this->input->post("kembalian");
	
	$data1=array("nota"=>$nota,
	"tanggal"=>$tgl,
	"ppn"=>$ppn,
	"jumlah"=>$total,
	"potongan"=>$potongan,
	"bayar"=>$bayar,
	"kembalian"=>$kembalian,
	"id_akun"=>$this->session->userdata("id"));
	$return_id=$this->M_Bqc->actTransaksi("tambah",$data1);
	if($return_id){
	$datakeuangan=array("tanggal"=>date("Y-m-d"),
	"keterangan"=>"Transaksi Dengan Nomor Nota : ".$nota,
	"masuk"=>($total-$potongan),
	"keluar"=>"0",
	"id_akun"=>$this->session->userdata("id"));
	$this->M_Bqc->actKeuangan("tambah",$datakeuangan);
	
	$kd=$this->input->post("kodebarang");
	$subtotal=$this->input->post("subtotal");
	if($kd==null){
	$data3=array("id_group_transaksi"=>$return_id,
	"id_pesanan"=>$this->input->post("koderoom"),
	"harga_pesanan"=>$this->input->post("totalroom")
	);
	$this->M_Bqc->actTransaksi("tambah2",$data3);
	$this->M_Bqc->bookingSelesai($this->input->post("koderoom"),$this->db->where("id_booking_room",$this->input->post("koderoom"))->get("booking_room")->row()->id_room);
	if(isset($_POST["print"])){
	//echo "<script>window.open('".base_url()."Admin/print_transaksi/".$return_id."','_blank');</script>";
	//echo '<meta http-equiv="refresh" content="0.2;url='.base_url().'Admin/transaksi" />';
	$this->print_transaksi($return_id);
	
	}else{
	redirect("Admin/transaksi");
	}
	}else{
	for($i=0;$i<count($kd);$i++){
	$data2=array("id_group_transaksi"=>$return_id,
	"id_pesanan"=>$kd[$i],
	"harga_pesanan"=>$subtotal[$i]
	);
	 $this->M_Bqc->actTransaksi("tambah2",$data2);
	 if($i==count($kd)-1){
	  if($this->input->post("roomOptions")=="include"){
	  $data3=array("id_group_transaksi"=>$return_id,
	  "id_pesanan"=>$this->input->post("koderoom"),
	  "harga_pesanan"=>$this->input->post("totalroom")
	  );
	  $this->M_Bqc->actTransaksi("tambah2",$data3);
	  $this->M_Bqc->bookingSelesai($this->input->post("koderoom"),$this->db->where("id_booking_room",$this->input->post("koderoom"))->get("booking_room")->row()->id_room);
	  }
	  if(isset($_POST["print"])){
	  //echo "<script>window.open('".base_url()."Admin/print_transaksi/".$return_id."','_blank');</script>";
	  //echo '<meta http-equiv="refresh" content="0.2;url='.base_url().'Admin/transaksi" />';
	  $this->print_transaksi($return_id);
	  }else{
	  redirect("Admin/transaksi");
	  }
	 }
	}
	}
	}
	}
	

	
	public function print_transaksi($id){
	$data["id"]=$id;
	 $this->load->view("print_transaksi",$data);
	}
	
	public function formTransaksi($id){
	 $data["group"]=$this->M_Bqc->formTransaksi("group_transaksi",$id);
	 $data["transaksi"]=$this->M_Bqc->formTransaksi("transaksi",$id);
	 $data["menu"]=$this->M_Bqc->transaksi("menu")->result();
	 $data["room"]=$this->M_Bqc->transaksi("room")->result();
	 $data["radio"]=$this->db->where("id_group_transaksi",$id)->like("id_pesanan","BR")->get("transaksi");
	 $data["total_isi"]=$this->db->where("id_group_transaksi",$id)->like("id_pesanan","M")->get("transaksi");
	 $this->bqc->view("transaksi/edit_transaksi",$data);
	}
	
	public function editTransaksi(){
	$id_group_transaksi=$this->input->post("id_group_transaksi");
	$nota=$this->input->post("nota");
	$tgl=$this->input->post("tanggal");
	$total=$this->input->post("grandtotal");
	$potongan=$this->input->post("potongan");
	$bayar=$this->input->post("bayar");
	$kembalian=$this->input->post("kembalian");
	
	$data1=array("nota"=>$nota,
	"tanggal"=>$tgl,
	"jumlah"=>$total,
	"potongan"=>$potongan,
	"bayar"=>$bayar,
	"kembalian"=>$kembalian,
	"id_akun"=>$this->session->userdata("id"));
	$this->M_Bqc->actEditTransaksi("edit",$id_group_transaksi,$data1);
	$kd=$this->input->post("kodebarang");
	$subtotal=$this->input->post("subtotal");
	if(count($kd)<=$this->input->post("totaldata")){
	 if($this->input->post("totaldataroom")=="0"){
	  $data3=array("id_group_transaksi"=>$id_group_transaksi,
	  "id_pesanan"=>$this->input->post("koderoom"),
	  "harga_pesanan"=>$this->input->post("totalroom")
	  );
	  $this->M_Bqc->actEditTransaksi("edit2",null,$data3);
	  $this->M_Bqc->bookingSelesai($this->input->post("koderoom"),$this->db->where("id_booking_room",$this->input->post("koderoom"))->get("booking_room")->row()->id_room);
	  if(isset($_POST["print"])){
	  //echo "<script>window.open('".base_url()."Admin/print_transaksi/".$id_group_transaksi."','_blank');</script>";
	  //echo '<meta http-equiv="refresh" content="0.2;url='.base_url().'Admin/daftar_transaksi" />';
	  
	  $this->print_transaksi($id_group_transaksi);
	  }else{
	  redirect("Admin/daftar_transaksi");
	  }
	 }
	}else{
	for($i=$this->input->post("totaldata");$i<count($kd);$i++){
	$data2=array("id_group_transaksi"=>$id_group_transaksi,
	"id_pesanan"=>$kd[$i],
	"harga_pesanan"=>$subtotal[$i]
	);
	$this->M_Bqc->actEditTransaksi("edit2",null,$data2);
	if($i==count($kd)-1){
	if($this->input->post("roomOptions")=="include"&&$this->input->post("totaldataroom")=="0"){
	$data3=array("id_group_transaksi"=>$id_group_transaksi,
	"id_pesanan"=>$this->input->post("koderoom"),
	"harga_pesanan"=>$this->input->post("totalroom")
	);
	$this->M_Bqc->actEditTransaksi("edit2",null,$data3);
	$this->M_Bqc->bookingSelesai($this->input->post("koderoom"),$this->db->where("id_booking_room",$this->input->post("koderoom"))->get("booking_room")->row()->id_room);
	}
	if(isset($_POST["print"])){
	//echo "<script>window.open('".base_url()."Admin/print_transaksi/".$id_group_transaksi."','_blank');</script>";
	//echo '<meta http-equiv="refresh" content="0.2;url='.base_url().'Admin/daftar_transaksi" />';
	$this->print_transaksi($id_group_transaksi);
	
	}else{
	redirect("Admin/daftar_transaksi");
	}
	}
	}
	}
	}
	
	public function detail_transaksi($id){
	 $data["group"]=$this->M_Bqc->formTransaksi("group_transaksi",$id);
	 $data["transaksi"]=$this->M_Bqc->formTransaksi("transaksi",$id);
	 $data["menu"]=$this->M_Bqc->transaksi("menu")->result();
	 $data["room"]=$this->M_Bqc->transaksi("room")->result();
	 $data["radio"]=$this->db->where("id_group_transaksi",$id)->like("id_pesanan","BR")->get("transaksi");
	 $data["total_isi"]=$this->db->where("id_group_transaksi",$id)->like("id_pesanan","M")->get("transaksi");
	 $this->bqc->view("detail_transaksi",$data);
	}
	
	
	public function printTransaksi($id){
	 $setting=$this->M_Bqc->setting();
	 $transaksi=$this->M_Bqc->formTransaksi("transaksi",$id);
	 $group=$this->M_Bqc->formTransaksi("group_transaksi",$id);
	 
	 $pdf=new FPDF("P","mm",array(200,180));
	 $pdf->addPage();
	 $pdf->SetFont("Arial","B","16");
	 $pdf->Cell(0,7,$setting->num_rows()>0 ? $setting->row()->header : "Masukkan Header",0,1,"C");
	 $pdf->SetFont("Arial","B","13");
	 $pdf->Cell(0,7,$setting->num_rows()>0 ? $setting->row()->sub_header : "Masukkan Sub Header",0,1,"C");
	 $pdf->Cell(0,7,"Nota : ".$group->row()->nota,0,1,"C");
	 $pdf->Cell(0,7,"",0,1,"C");
	 
	 
	 //Table Header
	 $pdf->SetFont("Arial","B","10");
	 $pdf->Cell(35,8,"KODE BARANG",1,0,"C");
	 $pdf->Cell(35,8,"NAMA",1,0,"C");
	 $pdf->Cell(35,8,"HARGA",1,0,"C");
	 $pdf->Cell(20,8,"JUMLAH",1,0,"C");
	 $pdf->Cell(35,8,"SUB TOTAL",1,1,"C");
	 //Table Body
	 $pdf->SetFont("Arial","","10");
	 foreach($transaksi->result() as $data){
	  $pdf->Cell(35,8,$data->id_pesanan,1,0,"C");
	  $pdf->Cell(35,8,$this->db->where('id_menu',$data->id_pesanan)->get('menu')->row()->nama_menu,1,0,"C");
	  $pdf->Cell(35,8,$this->db->where('id_menu',$data->id_pesanan)->get('menu')->row()->harga,1,0,"C");
	  $pdf->Cell(20,8,$data->harga_pesanan/$this->db->where('id_menu',$data->id_pesanan)->get('menu')->row()->harga,1,0,"C");
	  $pdf->Cell(35,8,$data->harga_pesanan,1,1,"C");
	 }
	 //Table Footer
	 //Grand Total
	 $pdf->Cell(20,8,"",0,0,"C");
	 $pdf->Cell(35,8,"",0,0,"C");
	 $pdf->Cell(35,8,"",0,0,"C");
	 $pdf->Cell(35,8,"Grand Total : ",0,0,"R");
	 $pdf->Cell(35,8,$group->row()->jumlah,0,1,"C");
	 //Potongan Harga
	 $pdf->Cell(20,8,"",0,0,"C");
	 $pdf->Cell(35,8,"",0,0,"C");
	 $pdf->Cell(35,8,"",0,0,"C");
	 $pdf->Cell(35,8,"Potongan Harga : ",0,0,"R");
	 $pdf->Cell(35,8,$group->row()->potongan,0,1,"C");
	 //Bayar
	 $pdf->Cell(20,8,"",0,0,"C");
	 $pdf->Cell(35,8,"",0,0,"C");
	 $pdf->Cell(35,8,"",0,0,"C");
	 $pdf->Cell(35,8,"Bayar : ",0,0,"R");
	 $pdf->Cell(35,8,$group->row()->bayar,0,1,"C");
	 //Kembalian
	 $pdf->Cell(20,8,"",0,0,"C");
	 $pdf->Cell(35,8,"",0,0,"C");
	 $pdf->Cell(35,8,"",0,0,"C");
	 $pdf->Cell(35,8,"Kembalian : ",0,0,"R");
	 $pdf->Cell(35,8,$group->row()->kembalian,0,1,"C");
	 
	 $pdf->SetFont("Arial","B","16");
	 $pdf->Cell(0,7,"",0,1,"C");
	 $pdf->Cell(0,7,$setting->num_rows()>0 ? $setting->row()->footer : "Masukkan Footer",0,1,"C");
	 
	 $pdf->Output();
	}
	
	//booking room
	public function booking_room(){
	 $this->bqc->view("booking_room",null);
	}
	
	public function getBooking($status){
	echo $this->M_Bqc->getBooking($status);
	}
	
	public function formBooking($type){
	 if($type=="tambah"){
	 $data["data_room"]=$this->M_Bqc->formBooking("room");
	 $this->bqc->view("booking_room/tambah_booking",$data);
	 }else{
	 $data["data_booking"]=$this->M_Bqc->formBooking($type)->row();
	 $this->bqc->view("booking_room/edit_booking",$data);
	 }
	}
	
	public function actBooking(){
	$type=$this->input->post("type");
	$id=$this->input->post("id");
	
	if($type=="tambah"){
	$id_booking="";
	if($this->db->get("booking_room")->num_rows()>0){
	$id_booking="BR".sprintf("%05s",(int)substr($this->db->query("SELECT MAX(id_booking_room) as id FROM booking_room")->row()->id,2,7)+1);
	}else{
	$id_booking="BR00001";
	}
	
	$data=array("id_booking_room"=>$id_booking,
	"id_room"=>$this->input->post("id_room"),
	"tanggal"=>$this->input->post("tanggal"),
	"mulai"=>$this->input->post("mulai"),
	"selesai"=>$this->input->post("selesai"),
	"tarif"=>$this->input->post("harga_booking"),
	"status"=>"proses",
	"id_akun"=>$this->session->userdata("id"));
	}elseif($type=="edit"){
	$data=array("id_booking_room"=>$id,
	"id_room"=>$this->input->post("id_room"),
	"tanggal"=>$this->input->post("tanggal"),
	"mulai"=>$this->input->post("mulai"),
	"selesai"=>$this->input->post("selesai"),
	"tarif"=>$this->input->post("harga_booking"),
	"status"=>"proses",
	"id_akun"=>$this->session->userdata("id"));
	}
	$this->M_Bqc->actBooking($type,$id,$data);
	redirect("Admin/booking_room");
	}
	
	public function bookingSelesai($id,$id_room){
	 $this->M_Bqc->bookingSelesai($id,$id_room);
	 redirect("Admin/booking_room");
	}
	
	
	//daftar transaksi
	public function daftar_transaksi(){
	 $this->bqc->view("daftar_transaksi",null);
	}
	
	public function getDaftarTransaksi(){
	echo $this->M_Bqc->getDaftarTransaksi();
	}
	
	
	//keuangan
	public function getKeuangan(){
	 echo $this->M_Bqc->getKeuangan();
	}
	
	public function keuangan(){
	 $this->bqc->view("keuangan",null);
	}
	
	public function actKeuangan(){
	 $id=$this->input->post("id_keuangan");
	 $tanggal=$this->input->post("tanggal_keuangan");
	 $keterangan=$this->input->post("keterangan_keuangan");
	 $masuk=$this->input->post("masuk_keuangan");
	 $keluar=$this->input->post("keluar_keuangan"); 
	 $data=array("tanggal"=>$tanggal,
	 "keterangan"=>$keterangan,
	 "masuk"=>$masuk,
	 "keluar"=>$keluar,
	 "id_akun"=>$this->session->userdata("id"));
	 $this->M_Bqc->actKeuangan($id,$data);
	 redirect("Admin/keuangan");
	}
	
	
	public function printKeuangan(){
	 $tgl_mulai=$this->input->post("tgl_mulai");
	 $tgl_akhir=$this->input->post("tgl_akhir");
	 
	 $setting=$this->db->get("setting")->row();
	 $sql=$this->db->where("tanggal>=",$tgl_mulai)->where("tanggal<=",$tgl_akhir)->get("keuangan");
	 
	 $excel=new PHPExcel();
	 
	 //Header
	 $excel->setActiveSheetIndex(0)->setCellValue("A1",$setting->header);
	 $excel->getActiveSheet()->mergeCells("A1:E1");
	 $excel->getActiveSheet()->getStyle("A1")->getFont()->setBold(TRUE);
	 $excel->getActiveSheet()->getStyle("A1")->getFont()->setSize(15);
	 $excel->getActiveSheet()->getStyle("A1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	 
	 //subHeader
	 $excel->setActiveSheetIndex(0)->setCellValue("A2",$setting->sub_header);
	 $excel->getActiveSheet()->mergeCells("A2:E2");
	 $excel->getActiveSheet()->getStyle("A2")->getFont()->setBold(TRUE);
	 $excel->getActiveSheet()->getStyle("A2")->getFont()->setSize(13);
	 $excel->getActiveSheet()->getStyle("A2")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	 
	 
	 //periode
	 $excel->setActiveSheetIndex(0)->setCellValue("A4","Periode : ".$tgl_mulai." Sampai ".$tgl_akhir);
	 $excel->getActiveSheet()->mergeCells("A4:E4");
	 $excel->getActiveSheet()->getStyle("A4")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
	 
	 
	 //Kolom
	 $excel->setActiveSheetIndex(0);
	 $excel->getActiveSheet()->setCellValue("A5","NO");
	 $excel->getActiveSheet()->setCellValue("B5","TANGGAL");
	 $excel->getActiveSheet()->setCellValue("C5","KETERANGAN");
	 $excel->getActiveSheet()->setCellValue("D5","MASUK");
	 $excel->getActiveSheet()->setCellValue("E5","KELUAR");
	 
	 
	 //set width Column
	 $excel->getActiveSheet()->getColumnDimension("A")->setWidth(5);
	 $excel->getActiveSheet()->getColumnDimension("B")->setWidth(15);
	 $excel->getActiveSheet()->getColumnDimension("C")->setWidth(50);
	 $excel->getActiveSheet()->getColumnDimension("D")->setWidth(10);
	 $excel->getActiveSheet()->getColumnDimension("E")->setWidth(10);
	 
	 $baris=6;
	 $no=1;
	 foreach($sql->result() as $td){
	  //Kolom
	  $excel->setActiveSheetIndex(0);
	  $excel->getActiveSheet()->setCellValue("A".$baris,$no);
	  $excel->getActiveSheet()->setCellValue("B".$baris,$td->tanggal);
	  $excel->getActiveSheet()->setCellValue("C".$baris,$td->keterangan);
	  $excel->getActiveSheet()->setCellValue("D".$baris,$td->masuk);
	  $excel->getActiveSheet()->setCellValue("E".$baris,$td->keluar);
	  
	  //set width Column
	  $excel->getActiveSheet()->getColumnDimension("A")->setWidth(5);
	  $excel->getActiveSheet()->getColumnDimension("B")->setWidth(15);
	  $excel->getActiveSheet()->getColumnDimension("C")->setWidth(50);
	  $excel->getActiveSheet()->getColumnDimension("D")->setWidth(10);
	  $excel->getActiveSheet()->getColumnDimension("E")->setWidth(10);
	  
	  $baris++;
	  $no++;
	  
	   if($baris==$sql->num_rows()+6){
	   	    
	   //TOTAL
	   $excel->setActiveSheetIndex(0)->setCellValue("A".$baris,"TOTAL : ");
	   $excel->getActiveSheet()->mergeCells("A".$baris.":C".$baris);
	   $excel->getActiveSheet()->getStyle("A".$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
	   $excel->setActiveSheetIndex(0)->setCellValue("D".$baris,$this->db->select_sum("masuk")->where("tanggal>=",$tgl_mulai)->where("tanggal<=",$tgl_akhir)->get("keuangan")->row()->masuk);
	   $excel->setActiveSheetIndex(0)->setCellValue("E".$baris,$this->db->select_sum("keluar")->where("tanggal>=",$tgl_mulai)->where("tanggal<=",$tgl_akhir)->get("keuangan")->row()->keluar);
	   
	   $baris+=1;
	   //SISA
	   $excel->setActiveSheetIndex(0)->setCellValue("A".$baris,"SISA : ");
	   $excel->getActiveSheet()->mergeCells("A".$baris.":C".$baris);
	   $excel->getActiveSheet()->getStyle("A".$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
	   $excel->setActiveSheetIndex(0)->setCellValue("D".$baris,$this->db->select_sum("masuk")->where("tanggal>=",$tgl_mulai)->where("tanggal<=",$tgl_akhir)->get("keuangan")->row()->masuk-$this->db->select_sum("keluar")->where("tanggal>=",$tgl_mulai)->where("tanggal<=",$tgl_akhir)->get("keuangan")->row()->keluar);
	   $excel->getActiveSheet()->mergeCells("D".$baris.":E".$baris);
	   $excel->getActiveSheet()->getStyle("D".$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	   
	   
	   //set width Column
	   $excel->getActiveSheet()->getColumnDimension("A")->setWidth(5);
	   $excel->getActiveSheet()->getColumnDimension("B")->setWidth(15);
	   $excel->getActiveSheet()->getColumnDimension("C")->setWidth(50);
	   $excel->getActiveSheet()->getColumnDimension("D")->setWidth(10);
	   $excel->getActiveSheet()->getColumnDimension("E")->setWidth(10);
	   
	   }
	 }
	 
	 
	 //set Height Column
	 $excel->getActiveSheet()->getRowDimension(1)->setRowHeight(25);
	 $excel->getActiveSheet()->getRowDimension(2)->setRowHeight(25);
	 
	 $cetak=PHPExcel_IOFactory::createWriter($excel,"Excel5");
	 header('Content-Type: application/vnd.ms-excel');
	 header('Content-Disposition: attachment;filename="Keuangan : '.$tgl_mulai.'-'.$tgl_akhir.'.xls"');
	 $cetak->save('php://output');
	}
	
	//menu
	public function menu(){
	 $this->bqc->view("menu",null);
	}
	
	public function getMenu(){
	 echo $this->M_Bqc->getMenu();
	}
	
	public function formMenu($type){
	if($type=="tambah"){
	$this->bqc->view("menu/tambah_menu",null);
	}else{
	$data["data_menu"]=$this->M_Bqc->menuById($type)->row();
	$this->bqc->view("menu/edit_menu",$data);
	}
	}
	
	
	public function actMenu(){
	$type=$this->input->post("type");
	$id=$this->input->post("id");
	
	if($type=="tambah"){
	 $id_menu="";
	 if($this->db->get("menu")->num_rows()>0){
	  $id_menu="M".sprintf("%05s",(int)substr($this->db->query("SELECT MAX(id_menu) as id FROM menu")->row()->id,1,5)+1);
	 }else{
	  $id_menu="M00001";
	 }
	$data=array("id_menu"=>$id_menu,
	"nama_menu"=>$this->input->post("nama"),
	"harga"=>$this->input->post("harga"),
	"id_akun"=>$this->session->userdata("id"));
	}elseif($type="edit"){
	$data=array("nama_menu"=>$this->input->post("nama"),
	"harga"=>$this->input->post("harga"),
	"id_akun"=>$this->session->userdata("id"));
	}
	
	$this->M_Bqc->actMenu($type,$id,$data);
	redirect("Admin/menu");
	}
	
	//room
	public function room(){
	 $this->bqc->view("room",null);
	}
	
	public function getRoom(){
	 echo $this->M_Bqc->getRoom();
	}
	
	public function formRoom($type){
	if($type=="tambah"){
	$this->bqc->view("room/tambah_room",null);
	}else{
	$data["data_room"]=$this->M_Bqc->roomById($type)->row();
	$this->bqc->view("room/edit_room",$data);
	}
	}
	
	public function actRoom(){
	$type=$this->input->post("type");
	$id=$this->input->post("id");
	
	if($type=="tambah"){
	$id_room="";
	if($this->db->get("room")->num_rows()>0){
	$id_room="R".sprintf("%05s",(int)substr($this->db->query("SELECT MAX(id_room) as id FROM room")->row()->id,1,5)+1);
	}else{
	$id_room="R00001";
	}
	$data=array("id_room"=>$id_room,
	"nama_room"=>$this->input->post("nama"),
	"harga"=>$this->input->post("harga"),
	"id_akun"=>$this->session->userdata("id"));
	}elseif($type=="edit"){
	 $data=array("nama_room"=>$this->input->post("nama"),
	 "harga"=>$this->input->post("harga"),
	 "id_akun"=>$this->session->userdata("id"));
	}
	
	$this->M_Bqc->actRoom($type,$id,$data);
	redirect("Admin/room");
	}
	
	//barang
	public function barang(){
	 $this->bqc->view("barang",null);
	}
	
	public function getBarang(){
	 echo $this->M_Bqc->getBarang();
	}
	
	public function formBarang($type){
	if($type=="tambah"){
	$this->bqc->view("barang/tambah_barang",null);
	}else{
	$data["data_barang"]=$this->M_Bqc->barangById($type)->row();
	$this->bqc->view("barang/edit_barang",$data);
	}
	}
	
	public function actBarang(){
	$type=$this->input->post("type");
	$id=$this->input->post("id");
	date_default_timezone_set("Asia/Jakarta");
	
	$data=array("nama_barang"=>$this->input->post("nama"),
	"stok"=>$this->input->post("stok"),
	"last_update"=>date("Y-m-d H:i:s"),
	"id_akun"=>$this->session->userdata("id"));
	
	$this->M_Bqc->actBarang($type,$id,$data);
	redirect("Admin/barang");
	}
	
	public function printBarang(){
	 
	 $setting=$this->db->get("setting")->row();
	 $sql=$this->db->get("barang");
	
	 $excel=new PHPExcel();
	 
	 //Header
	 $excel->setActiveSheetIndex(0)->setCellValue("A1",$setting->header);
	 $excel->getActiveSheet()->mergeCells("A1:C1");
	 $excel->getActiveSheet()->getStyle("A1")->getFont()->setBold(TRUE);
	 $excel->getActiveSheet()->getStyle("A1")->getFont()->setSize(15);
	 $excel->getActiveSheet()->getStyle("A1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	 
	 //subHeader
	 $excel->setActiveSheetIndex(0)->setCellValue("A2",$setting->sub_header);
	 $excel->getActiveSheet()->mergeCells("A2:C2");
	 $excel->getActiveSheet()->getStyle("A2")->getFont()->setBold(TRUE);
	 $excel->getActiveSheet()->getStyle("A2")->getFont()->setSize(13);
	 $excel->getActiveSheet()->getStyle("A2")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	 
	 
	 //periode
	 $excel->setActiveSheetIndex(0)->setCellValue("A4","Tanggal : ".date("Y-m-d"));
	 $excel->getActiveSheet()->mergeCells("A4:C4");
	 $excel->getActiveSheet()->getStyle("A4")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
	 
	 
	 //Kolom
	 $excel->setActiveSheetIndex(0);
	 $excel->getActiveSheet()->setCellValue("A5","NO");
	 $excel->getActiveSheet()->setCellValue("B5","NAMA BARANG");
	 $excel->getActiveSheet()->setCellValue("C5","STOK");
	 
	 //set width Column
	 $excel->getActiveSheet()->getColumnDimension("A")->setWidth(5);
	 $excel->getActiveSheet()->getColumnDimension("B")->setWidth(25);
	 $excel->getActiveSheet()->getColumnDimension("C")->setWidth(10);
	 
	 $baris=6;
	 $no=1;
	 foreach($sql->result() as $td){
	 //Kolom
	 $excel->setActiveSheetIndex(0);
	 $excel->getActiveSheet()->setCellValue("A".$baris,$no);
	 $excel->getActiveSheet()->setCellValue("B".$baris,$td->nama_barang);
	 $excel->getActiveSheet()->setCellValue("C".$baris,$td->stok);
	 
	 //set width Column
	 $excel->getActiveSheet()->getColumnDimension("A")->setWidth(5);
	 $excel->getActiveSheet()->getColumnDimension("B")->setWidth(25);
	 $excel->getActiveSheet()->getColumnDimension("C")->setWidth(10);

	 $baris++;
	 $no++;
	 }
	 
	 
	 //set Height Column
	 $excel->getActiveSheet()->getRowDimension(1)->setRowHeight(25);
	 $excel->getActiveSheet()->getRowDimension(2)->setRowHeight(25);
	 
	 $cetak=PHPExcel_IOFactory::createWriter($excel,"Excel5");
	 header('Content-Type: application/vnd.ms-excel');
	 header('Content-Disposition: attachment;filename="Barang : '.date("Y-m-d").'.xls"');
	 $cetak->save('php://output');
	}
	
	//admin
	public function admin(){
	 $this->bqc->view("admin",null);
	}
	
	public function getAdmin(){
	 echo $this->M_Bqc->getAdmin();
	}
	
	public function formAdmin($type){
	if($type=="tambah"){
	 $this->bqc->view("admin/tambah_admin",null);
	}else{
	 $data["data_akun"]=$this->M_Bqc->adminById($type)->row();
	 $this->bqc->view("admin/edit_admin",$data);
	}
	}
	
	public function actAdmin(){
	$type=$this->input->post("type");
	$id=$this->input->post("id");
	date_default_timezone_set("Asia/Jakarta");

	$data=array("nama_akun"=>$this->input->post("nama"),
	"username"=>$this->input->post("username"),
	"password"=>$this->input->post("password"),
	"level"=>$this->input->post("level"),
	"last_login"=>date("Y-m-d H:i:s"));
	
	$this->M_Bqc->actAdmin($type,$id,$data);
	redirect("Admin/admin");
	}
	
	//setting
	public function setting(){
	 $data["setting"]=$this->M_Bqc->setting();
	 $this->bqc->view("setting",$data);
	}
	
	public function actSetting(){
	 $header=$this->input->post("header");
	 $subheader=$this->input->post("subheader");
	 $footer=$this->input->post("footer");
	 $this->M_Bqc->actSetting(array("header"=>$header,"sub_header"=>$subheader,"footer"=>$footer));
	 redirect("Admin/setting");
	}
	
	//hapus data
	public function hapusdata(){
	$type=$this->input->post("type_hapus");
	$id=$this->input->post("id_hapus");
	$this->M_Bqc->hapusdata($type,$id);
	redirect("Admin/".$type);
	}
	
	
	public function pick(){
	 $this->bqc->view("pick",null);
	}
	
}