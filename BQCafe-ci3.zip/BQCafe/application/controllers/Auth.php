<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	
	function __constructor(){
	 parent::__constructor();
	 $this->load->library("bqc");
	}
	
	public function index(){
	 redirect("Auth/login");
	}
	
	public function login(){
	 $this->load->view('login');
	}
	
	public function actLogin(){
	 $username=$this->input->post("username");
	 $password=$this->input->post("password");
	 $sql=$this->db->where(array("username"=>$username,"password"=>$password))->get("akun");
	 if($sql->num_rows()>0){
	 date_default_timezone_set("Asia/Jakarta");
	  $this->db->where("id_akun",$sql->row()->id_akun)->update("akun",array("last_login"=>(string)date("Y-m-d H:i:s")));
	  $this->session->set_userdata("id",$sql->row()->id_akun);
	  $this->session->set_userdata("level",$sql->row()->level);
	  redirect($sql->row()->level);
	 }else{
	  redirect("Auth/login");
	 }
	}
	
	public function logout(){
	 $this->session->unset_userdata("id");
	 $this->session->unset_userdata("level");
	 redirect("Auth/login");
	}
}