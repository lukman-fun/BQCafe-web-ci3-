<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kasir extends CI_Controller {
	
	function __construct(){
	 parent::__construct();
	 $this->load->library("bqc");
	 $this->load->model("M_Bqc");
	}
	
	//dashboard
	public function index(){
	$data["menu"]=$this->M_Bqc->dashboard("menu");
	$data["room"]=$this->M_Bqc->dashboard("room");
	$data["grafik"]=$this->M_Bqc->dashboard("grafik");
	$data["data_grafik"]=$this->M_Bqc->grafik()->result();
	$this->bqc->view("dashboard",$data);
	}
	
	//Transaksi
	public function transaksi(){
	$data["menu"]=$this->M_Bqc->transaksi("menu")->result();
	$data["room"]=$this->M_Bqc->transaksi("room")->result();
	if($this->M_Bqc->transaksi("kode")->num_rows()>0){
	$kode=(int)substr($this->M_Bqc->transaksi("kode")->row()->nota,8,12);
	$data["kode"]="BQ".date("ymd").sprintf("%05s",$kode+1);
	}else{
	$data["kode"]="BQ".date("ymd")."00001";
	}
	$this->bqc->view("transaksi",$data);
	}
	
	public function addTransaksi(){
	//variabel menu
	$nota=$this->input->post("nota");
	$tgl=$this->input->post("tanggal");
	$ppn=$this->input->post("ppn");
	$total=$this->input->post("grandtotal");
	$potongan=$this->input->post("potongan");
	$bayar=$this->input->post("bayar");
	$kembalian=$this->input->post("kembalian");
	
	$data1=array("nota"=>$nota,
	"tanggal"=>$tgl,
	"ppn"=>$ppn,
	"jumlah"=>$total,
	"potongan"=>$potongan,
	"bayar"=>$bayar,
	"kembalian"=>$kembalian,
	"id_akun"=>$this->session->userdata("id"));
	$return_id=$this->M_Bqc->actTransaksi("tambah",$data1);
	if($return_id){
	$datakeuangan=array("tanggal"=>date("Y-m-d"),
	"keterangan"=>"Transaksi Dengan Nomor Nota : ".$nota,
	"masuk"=>($total-$potongan),
	"keluar"=>"0",
	"id_akun"=>$this->session->userdata("id"));
	$this->M_Bqc->actKeuangan("tambah",$datakeuangan);
	
	$kd=$this->input->post("kodebarang");
	$subtotal=$this->input->post("subtotal");
	if($kd==null){
	$data3=array("id_group_transaksi"=>$return_id,
	"id_pesanan"=>$this->input->post("koderoom"),
	"harga_pesanan"=>$this->input->post("totalroom")
	);
	$this->M_Bqc->actTransaksi("tambah2",$data3);
	$this->M_Bqc->bookingSelesai($this->input->post("koderoom"),$this->db->where("id_booking_room",$this->input->post("koderoom"))->get("booking_room")->row()->id_room);
	if(isset($_POST["print"])){
	//echo "<script>window.open('".base_url()."Kasir/print_transaksi/".$return_id."','_blank');</script>";
	//echo '<meta http-equiv="refresh" content="0.2;url='.base_url().'Kasir/transaksi" />';
	$this->print_transaksi($return_id);
	}else{
	redirect("Kasir/transaksi");
	}
	}else{
	for($i=0;$i<count($kd);$i++){
	$data2=array("id_group_transaksi"=>$return_id,
	"id_pesanan"=>$kd[$i],
	"harga_pesanan"=>$subtotal[$i]
	);
	$this->M_Bqc->actTransaksi("tambah2",$data2);
	if($i==count($kd)-1){
	if($this->input->post("roomOptions")=="include"){
	$data3=array("id_group_transaksi"=>$return_id,
	"id_pesanan"=>$this->input->post("koderoom"),
	"harga_pesanan"=>$this->input->post("totalroom")
	);
	$this->M_Bqc->actTransaksi("tambah2",$data3);
	$this->M_Bqc->bookingSelesai($this->input->post("koderoom"),$this->db->where("id_booking_room",$this->input->post("koderoom"))->get("booking_room")->row()->id_room);
	}
	if(isset($_POST["print"])){
	//echo "<script>window.open('".base_url()."Kasir/print_transaksi/".$return_id."','_blank');</script>";
	//echo '<meta http-equiv="refresh" content="0.2;url='.base_url().'Kasir/transaksi" />';
	$this->print_transaksi($return_id);
	}else{
	redirect("Kasir/transaksi");
	}
	}
	}
	}
	}
	}
	
	
	public function print_transaksi($id){
	$data["id"]=$id;
	$this->load->view("print_transaksi",$data);
	}
	
	
	public function printTransaksi($id){
	$setting=$this->M_Bqc->setting();
	$transaksi=$this->M_Bqc->formTransaksi("transaksi",$id);
	$group=$this->M_Bqc->formTransaksi("group_transaksi",$id);
	
	$pdf=new FPDF("P","mm",array(55));
	$pdf->addPage();
	$pdf->SetFont("Arial","B","16");
	$pdf->Cell(0,7,$setting->num_rows()>0 ? $setting->row()->header : "Masukkan Header",0,1,"C");
	$pdf->SetFont("Arial","B","13");
	$pdf->Cell(0,7,$setting->num_rows()>0 ? $setting->row()->sub_header : "Masukkan Sub Header",0,1,"C");
	$pdf->Cell(0,7,"Nota : ".$group->row()->nota,0,1,"C");
	$pdf->Cell(0,7,"",0,1,"C");
	
	
	//Table Header
	$pdf->SetFont("Arial","B","10");
	$pdf->Cell(35,8,"KODE BARANG",1,0,"C");
	$pdf->Cell(35,8,"NAMA",1,0,"C");
	$pdf->Cell(35,8,"HARGA",1,0,"C");
	$pdf->Cell(20,8,"JUMLAH",1,0,"C");
	$pdf->Cell(35,8,"SUB TOTAL",1,1,"C");
	//Table Body
	$pdf->SetFont("Arial","","10");
	foreach($transaksi->result() as $data){
	$pdf->Cell(35,8,$data->id_pesanan,1,0,"C");
	$pdf->Cell(35,8,$this->db->where('id_menu',$data->id_pesanan)->get('menu')->row()->nama_menu,1,0,"C");
	$pdf->Cell(35,8,$this->db->where('id_menu',$data->id_pesanan)->get('menu')->row()->harga,1,0,"C");
	$pdf->Cell(20,8,$data->harga_pesanan/$this->db->where('id_menu',$data->id_pesanan)->get('menu')->row()->harga,1,0,"C");
	$pdf->Cell(35,8,$data->harga_pesanan,1,1,"C");
	}
	//Table Footer
	//Grand Total
	$pdf->Cell(20,8,"",0,0,"C");
	$pdf->Cell(35,8,"",0,0,"C");
	$pdf->Cell(35,8,"",0,0,"C");
	$pdf->Cell(35,8,"Grand Total : ",0,0,"R");
	$pdf->Cell(35,8,$group->row()->jumlah,1,1,"C");
	//Potongan Harga
	$pdf->Cell(20,8,"",0,0,"C");
	$pdf->Cell(35,8,"",0,0,"C");
	$pdf->Cell(35,8,"",0,0,"C");
	$pdf->Cell(35,8,"Potongan Harga : ",0,0,"R");
	$pdf->Cell(35,8,$group->row()->potongan,1,1,"C");
	//Bayar
	$pdf->Cell(20,8,"",0,0,"C");
	$pdf->Cell(35,8,"",0,0,"C");
	$pdf->Cell(35,8,"",0,0,"C");
	$pdf->Cell(35,8,"Bayar : ",0,0,"R");
	$pdf->Cell(35,8,$group->row()->bayar,1,1,"C");
	//Kembalian
	$pdf->Cell(20,8,"",0,0,"C");
	$pdf->Cell(35,8,"",0,0,"C");
	$pdf->Cell(35,8,"",0,0,"C");
	$pdf->Cell(35,8,"Kembalian : ",0,0,"R");
	$pdf->Cell(35,8,$group->row()->kembalian,1,1,"C");
	
	$pdf->SetFont("Arial","B","16");
	$pdf->Cell(0,7,"",0,1,"C");
	$pdf->Cell(0,7,$setting->num_rows()>0 ? $setting->row()->footer : "Masukkan Footer",0,1,"C");
	
	$pdf->Output();
	}
	
	
	public function booking_room(){
	$this->bqc->view("booking_room",null);
	}
	
	public function formBooking($type){
	if($type=="tambah"){
	$data["data_room"]=$this->M_Bqc->formBooking("room");
	$this->bqc->view("booking_room/tambah_booking",$data);
	}else{
	$data["data_booking"]=$this->M_Bqc->formBooking($type)->row();
	$this->bqc->view("booking_room/edit_booking",$data);
	}
	}
	
	public function actBooking(){
	$type=$this->input->post("type");
	$id=$this->input->post("id");
	
	$id_booking="";
	if($this->db->get("booking_room")->num_rows()>0){
	$id_booking="BR".sprintf("%05s",(int)substr($this->db->query("SELECT MAX(id_booking_room) as id FROM booking_room")->row()->id,2,7)+1);
	}else{
	$id_booking="BR00001";
	}
	
	$data=array("id_booking_room"=>$id_booking,
	"id_room"=>$this->input->post("id_room"),
	"tanggal"=>$this->input->post("tanggal"),
	"mulai"=>$this->input->post("mulai"),
	"selesai"=>$this->input->post("selesai"),
	"tarif"=>$this->input->post("harga_booking"),
	"status"=>"proses",
	"id_akun"=>$this->session->userdata("id"));
	
	$this->M_Bqc->actBooking($type,$id,$data);
	redirect("Kasir/booking_room");
	}
	
	public function bookingSelesai($id,$id_room){
	$this->M_Bqc->bookingSelesai($id,$id_room);
	redirect("Kasir/booking_room");
	}
	
	//hapus data
	public function hapusdata(){
	$type=$this->input->post("type_hapus");
	$id=$this->input->post("id_hapus");
	$this->M_Bqc->hapusdata($type,$id);
	redirect("Kasir/".$type);
	}
	
}