<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	
	function __construct(){
	 parent::__construct();
	 $this->load->library("bqc");
	 $this->load->library("Excel/phpexcel","excel");
	 $this->load->model("M_Bqc");
	}
	
	//dashboard
	public function index(){
	$data["menu"]=$this->M_Bqc->dashboard("menu");
	$data["room"]=$this->M_Bqc->dashboard("room");
	$data["grafik"]=$this->M_Bqc->dashboard("grafik");
	$data["data_grafik"]=$this->M_Bqc->grafik()->result();
	$this->bqc->view("dashboard",$data);
	}
	
	//keuangan
	public function keuangan(){
	$this->bqc->view("keuangan",null);
	}
	
	public function actKeuangan(){
	$id=$this->input->post("id_keuangan");
	$tanggal=$this->input->post("tanggal_keuangan");
	$keterangan=$this->input->post("keterangan_keuangan");
	$masuk=$this->input->post("masuk_keuangan");
	$keluar=$this->input->post("keluar_keuangan"); 
	$data=array("tanggal"=>$tanggal,
	"keterangan"=>$keterangan,
	"masuk"=>$masuk,
	"keluar"=>$keluar,
	"id_akun"=>$this->session->userdata("id"));
	$this->M_Bqc->actKeuangan($id,$data);
	redirect("User/keuangan");
	}
	
	public function printKeuangan(){
	$tgl_mulai=$this->input->post("tgl_mulai");
	$tgl_akhir=$this->input->post("tgl_akhir");
	
	$setting=$this->db->get("setting")->row();
	$sql=$this->db->where("tanggal>=",$tgl_mulai)->where("tanggal<=",$tgl_akhir)->get("keuangan");
	
	$excel=new PHPExcel();
	
	//Header
	$excel->setActiveSheetIndex(0)->setCellValue("A1",$setting->header);
	$excel->getActiveSheet()->mergeCells("A1:E1");
	$excel->getActiveSheet()->getStyle("A1")->getFont()->setBold(TRUE);
	$excel->getActiveSheet()->getStyle("A1")->getFont()->setSize(15);
	$excel->getActiveSheet()->getStyle("A1")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	
	//subHeader
	$excel->setActiveSheetIndex(0)->setCellValue("A2",$setting->sub_header);
	$excel->getActiveSheet()->mergeCells("A2:E2");
	$excel->getActiveSheet()->getStyle("A2")->getFont()->setBold(TRUE);
	$excel->getActiveSheet()->getStyle("A2")->getFont()->setSize(13);
	$excel->getActiveSheet()->getStyle("A2")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	
	
	//periode
	$excel->setActiveSheetIndex(0)->setCellValue("A4","Periode : ".$tgl_mulai." Sampai ".$tgl_akhir);
	$excel->getActiveSheet()->mergeCells("A4:E4");
	$excel->getActiveSheet()->getStyle("A4")->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
	
	
	//Kolom
	$excel->setActiveSheetIndex(0);
	$excel->getActiveSheet()->setCellValue("A5","NO");
	$excel->getActiveSheet()->setCellValue("B5","TANGGAL");
	$excel->getActiveSheet()->setCellValue("C5","KETERANGAN");
	$excel->getActiveSheet()->setCellValue("D5","MASUK");
	$excel->getActiveSheet()->setCellValue("E5","KELUAR");
	
	
	//set width Column
	$excel->getActiveSheet()->getColumnDimension("A")->setWidth(5);
	$excel->getActiveSheet()->getColumnDimension("B")->setWidth(15);
	$excel->getActiveSheet()->getColumnDimension("C")->setWidth(50);
	$excel->getActiveSheet()->getColumnDimension("D")->setWidth(10);
	$excel->getActiveSheet()->getColumnDimension("E")->setWidth(10);
	
	$baris=6;
	$no=1;
	foreach($sql->result() as $td){
	//Kolom
	$excel->setActiveSheetIndex(0);
	$excel->getActiveSheet()->setCellValue("A".$baris,$no);
	$excel->getActiveSheet()->setCellValue("B".$baris,$td->tanggal);
	$excel->getActiveSheet()->setCellValue("C".$baris,$td->keterangan);
	$excel->getActiveSheet()->setCellValue("D".$baris,$td->masuk);
	$excel->getActiveSheet()->setCellValue("E".$baris,$td->keluar);
	
	//set width Column
	$excel->getActiveSheet()->getColumnDimension("A")->setWidth(5);
	$excel->getActiveSheet()->getColumnDimension("B")->setWidth(15);
	$excel->getActiveSheet()->getColumnDimension("C")->setWidth(50);
	$excel->getActiveSheet()->getColumnDimension("D")->setWidth(10);
	$excel->getActiveSheet()->getColumnDimension("E")->setWidth(10);
	
	$baris++;
	$no++;
	
	if($baris==$sql->num_rows()+6){
	
	//TOTAL
	$excel->setActiveSheetIndex(0)->setCellValue("A".$baris,"TOTAL : ");
	$excel->getActiveSheet()->mergeCells("A".$baris.":C".$baris);
	$excel->getActiveSheet()->getStyle("A".$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
	$excel->setActiveSheetIndex(0)->setCellValue("D".$baris,$this->db->select_sum("masuk")->where("tanggal>=",$tgl_mulai)->where("tanggal<=",$tgl_akhir)->get("keuangan")->row()->masuk);
	$excel->setActiveSheetIndex(0)->setCellValue("E".$baris,$this->db->select_sum("keluar")->where("tanggal>=",$tgl_mulai)->where("tanggal<=",$tgl_akhir)->get("keuangan")->row()->keluar);
	
	$baris+=1;
	//SISA
	$excel->setActiveSheetIndex(0)->setCellValue("A".$baris,"SISA : ");
	$excel->getActiveSheet()->mergeCells("A".$baris.":C".$baris);
	$excel->getActiveSheet()->getStyle("A".$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
	$excel->setActiveSheetIndex(0)->setCellValue("D".$baris,$this->db->select_sum("masuk")->where("tanggal>=",$tgl_mulai)->where("tanggal<=",$tgl_akhir)->get("keuangan")->row()->masuk-$this->db->select_sum("keluar")->where("tanggal>=",$tgl_mulai)->where("tanggal<=",$tgl_akhir)->get("keuangan")->row()->keluar);
	$excel->getActiveSheet()->mergeCells("D".$baris.":E".$baris);
	$excel->getActiveSheet()->getStyle("D".$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	
	
	//set width Column
	$excel->getActiveSheet()->getColumnDimension("A")->setWidth(5);
	$excel->getActiveSheet()->getColumnDimension("B")->setWidth(15);
	$excel->getActiveSheet()->getColumnDimension("C")->setWidth(50);
	$excel->getActiveSheet()->getColumnDimension("D")->setWidth(10);
	$excel->getActiveSheet()->getColumnDimension("E")->setWidth(10);
	
	}
	}
	
	
	//set Height Column
	$excel->getActiveSheet()->getRowDimension(1)->setRowHeight(25);
	$excel->getActiveSheet()->getRowDimension(2)->setRowHeight(25);
	
	$cetak=PHPExcel_IOFactory::createWriter($excel,"Excel5");
	header('Content-Type: application/vnd.ms-excel');
	header('Content-Disposition: attachment;filename="Keuangan : '.$tgl_mulai.'-'.$tgl_akhir.'.xls"');
	$cetak->save('php://output');
	}
	
	//barang
	public function barang(){
	$this->bqc->view("barang",null);
	}
	
	public function formBarang($type){
	if($type=="tambah"){
	$this->bqc->view("barang/tambah_barang",null);
	}else{
	$data["data_barang"]=$this->M_Bqc->barangById($type)->row();
	$this->bqc->view("barang/edit_barang",$data);
	}
	}
	
	public function actBarang(){
	$type=$this->input->post("type");
	$id=$this->input->post("id");
	date_default_timezone_set("Asia/Jakarta");
	
	$data=array("nama_barang"=>$this->input->post("nama"),
	"stok"=>$this->input->post("stok"),
	"last_update"=>date("Y-m-d H:i:s"),
	"id_akun"=>$this->session->userdata("id"));
	
	$this->M_Bqc->actBarang($type,$id,$data);
	redirect("User/barang");
	}
	//hapus data
	public function hapusdata(){
	$type=$this->input->post("type_hapus");
	$id=$this->input->post("id_hapus");
	$this->M_Bqc->hapusdata($type,$id);
	redirect("User/".$type);
	}

}