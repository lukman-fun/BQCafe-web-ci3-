<?php

class Bqc{

 protected $CI;
 function __construct(){
 $this->CI =&get_instance();
 }
 //Fungsi Load
 function view($view,$data){
 $this->CI->load->view("navbar");
 $this->CI->load->view($view,$data);
 $this->CI->load->view("footer");
 return;
 }
 
 function waktu(){
 date_default_timezone_set('Asia/Jakarta');
 $tanggal=date("Y-m-d H:i:s");
 echo "".$tanggal;
 }
 
}