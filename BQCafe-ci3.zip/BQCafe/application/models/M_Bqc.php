<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Bqc extends CI_Model{
 
 function __construct(){
  parent::__construct();
  $this->load->library("datatables");
 }
 
 //dashboard
 function dashboard($type){
  if($type=="menu"){
   return $this->db->get("menu")->num_rows();
  }elseif($type=="room"){
   return $this->db->get("room")->num_rows();
  }elseif($type=="grafik"){
   return $this->db->query("SELECT * FROM group_transaksi WHERE MONTH(tanggal)=MONTH(NOW())")->num_rows();
  }
 }
 
 function grafik(){
  return $this->db->query("SELECT DATE(tanggal) as tanggal,SUM(jumlah) as jumlah FROM group_transaksi WHERE MONTH(tanggal)=MONTH(NOW()) GROUP BY DATE(tanggal)");
 }
 
 //transaksi
 function transaksi($type){
  if($type=="menu"){
  return $this->db->order_by("id_menu","desc")->get("menu");
  }elseif($type=="room"){
  return $this->db->select("booking_room.id_booking_room,booking_room.tarif,room.nama_room,booking_room.tanggal")->from("booking_room")->join("room","booking_room.id_room=room.id_room","inner")->where("booking_room.status","proses")->get();
  }elseif($type="kode"){
  return $this->db->query("SELECT * FROM group_transaksi WHERE DATE(tanggal)=DATE(NOW()) ORDER BY id_group_transaksi");
  }
 }
 
 function actTransaksi($type,$data){
 if($type=="tambah"){
 $this->db->insert("group_transaksi",$data);
 return $this->db->insert_id();
 }elseif($type=="tambah2"){
 $this->db->insert("transaksi",$data);
 }
 }
 
 function formTransaksi($tb,$id){
  return $this->db->where("id_group_transaksi",$id)->get($tb);
 }
 
 function getRoomTransaksi($id_pesanan){
  return $this->db->select("booking_room.tarif,room.nama_room")->from("transaksi")->join("booking_room","transaksi.id_pesanan=booking_room.id_booking_room","inner")->join("room","room.id_room=booking_room.id_room","inner")->where("transaksi.id_pesanan",$id_pesanan)->get();
 }
 
 function actEditTransaksi($type,$id,$data){
 if($type=="edit"){
 $this->db->where("id_group_transaksi",$id)->update("group_transaksi",$data);
 }elseif($type=="edit2"){
 $this->db->insert("transaksi",$data);
 }
 }
 
 //booking
 function getBooking($status){
 if($status=="proses"){
 $this->datatables->select("id_booking_room,id_room,DAY(tanggal) as hari,MONTH(tanggal) as bulan,YEAR(tanggal) as tahun,mulai,selesai,tarif,status,id_akun")->where("status",$status)->from("booking_room")->add_column("tanggal","$1-$2-$3","hari,bulan,tahun")->add_column('aksi','<div class="btn-group"><a href="formBooking/$1" class="btn btn-info">Edit</a><button class="btn btn-danger" onclick="modalhapus(`booking_room`,`$1`)" data-toggle="modal" data-target="#modalhapus">Delete</button> <a href="bookingSelesai/$1/$2" class="btn btn-warning">Selesai</a></div>','id_booking_room,id_room');
 }else{
 $this->datatables->select("id_booking_room,id_room,DAY(tanggal) as hari,MONTH(tanggal) as bulan,YEAR(tanggal) as tahun,mulai,selesai,tarif,status,id_akun")->where("status",$status)->from("booking_room")->add_column("tanggal","$1-$2-$3","hari,bulan,tahun")->add_column('aksi','<div class="btn-group"><button class="btn btn-danger" onclick="modalhapus(`booking_room`,`$1`)" data-toggle="modal" data-target="#modalhapus">Delete</button></div>','id_booking_room');
 }
 return $this->datatables->generate();
 }
 
 function formBooking($type){
  if($type=="room"){
  return $this->db->where("status","true")->order_by("id_room","desc")->get("room");
  }else{
  return $this->db->select("booking_room.id_booking_room,booking_room.id_room,booking_room.tanggal,booking_room.mulai, booking_room.selesai,booking_room.tarif, booking_room.status, booking_room.id_akun,room.harga")->from("booking_room")->join("room","booking_room.id_room=room.id_room","inner")->where("id_booking_room",$type)->get();
  }
 }
 
 function actBooking($type,$id,$data){
 if($type=="tambah"){
 $this->db->where("id_room",$data["id_room"])->update("room",array("status"=>"false"));
 $this->db->insert("booking_room",$data);
 }elseif($type=="edit"){
 $this->db->where("id_booking_room",$id)->update("booking_room",$data);
 }
 }
 
 function bookingSelesai($id,$id_room){
  $this->db->where("id_room",$id_room)->update("room",array("status"=>"true"));
  $this->db->where("id_booking_room",$id)->update("booking_room",array("status"=>"selesai"));
 }
 
 
 //daftar transaksi
 function getDaftarTransaksi(){
 $this->datatables->select("id_group_transaksi,nota,DAY(tanggal) as hari,MONTH(tanggal) as bulan,YEAR(tanggal) as tahun,HOUR(tanggal) as jam,MINUTE(tanggal) as menit,SECOND(tanggal) as detik")->from("group_transaksi")->add_column("tanggal","$1-$2-$3 $4:$5:$6","hari,bulan,tahun,jam,menit,detik")->add_column('aksi','<div class="btn-group"><a href="detail_transaksi/$1" class="btn btn-success">Detail</a> <a href="formTransaksi/$1" class="btn btn-info">Edit</a> <a href="print_transaksi/$1" class="btn btn-warning">Cetak</a> <button class="btn btn-danger" onclick="modalhapus(`daftar_transaksi`,`$1`)" data-toggle="modal" data-target="#modalhapus">Delete</button></div>','id_group_transaksi');
 return $this->datatables->generate();
 }
 
 //keuangan
 function getKeuangan(){
 $this->datatables->select("id_keuangan,DAY(tanggal) as hari,MONTH(tanggal) as bulan,YEAR(tanggal) as tahun,keterangan,masuk,keluar")->from("keuangan")->add_column("tanggal","$1-$2-$3","hari,bulan,tahun")->add_column('aksi','<div class="btn-group"><button  class="btn btn-info" onclick="modal_keuangan(`$1`,`$2`,`$3`,`$4`,`$5`)" data-toggle="modal" data-target="#modalkeuangan">Edit</button> <button class="btn btn-danger" onclick="modalhapus(`keuangan`,`$1`)" data-toggle="modal" data-target="#modalhapus">Delete</button></div>','id_keuangan,tanggal,keterangan,masuk,keluar');
 return $this->datatables->generate();
 }
 
 function actKeuangan($id,$data){
  if($id=="tambah"){
   $this->db->insert("keuangan",$data);
  }else{
   $this->db->where("id_keuangan",$id)->update("keuangan",$data);
  }
 }

 
 //Menu
 function getMenu(){
  $this->datatables->select("id_menu,nama_menu,harga")->from("menu")->add_column('aksi','<div class="btn-group"><a href="formMenu/$1" class="btn btn-info">Edit</a> <button class="btn btn-danger" onclick="modalhapus(`menu`,`$1`)" data-toggle="modal" data-target="#modalhapus">Delete</button></div>','id_menu');
  return $this->datatables->generate();
 }
 
 function actMenu($type,$id,$data){
 if($type=="tambah"){
 $this->db->insert("menu",$data);
 }elseif($type=="edit"){
 $this->db->where("id_menu",$id)->update("menu",$data);
 }
 }
 
 function menuById($id){
 return $this->db->where("id_menu",$id)->get("menu");
 }
 
 //Room
 function getRoom(){
  $this->datatables->select("id_room,nama_room,harga")->from("room")->add_column('aksi','<div class="btn-group"><a href="formRoom/$1" class="btn btn-info">Edit</a> <button class="btn btn-danger" onclick="modalhapus(`room`,`$1`)" data-toggle="modal" data-target="#modalhapus">Delete</button></div>','id_room');
  return $this->datatables->generate();
 }
 
 function actRoom($type,$id,$data){
 if($type=="tambah"){
 $this->db->insert("room",$data);
 }elseif($type=="edit"){
 $this->db->where("id_room",$id)->update("room",$data);
 }
 }
 
 function roomById($id){
 return $this->db->where("id_room",$id)->get("room");
 }
 
 //Barang
 function getBarang(){
  $this->datatables->select("id_barang,nama_barang,stok")->from("barang")->add_column('aksi','<div class="btn-group"><a href="formBarang/$1" class="btn btn-info">Edit</a> <button class="btn btn-danger" onclick="modalhapus(`barang`,`$1`)" data-toggle="modal" data-target="#modalhapus">Delete</button></div>','id_barang');
  return $this->datatables->generate();
 }
 
 function actBarang($type,$id,$data){
 if($type=="tambah"){
 $this->db->insert("barang",$data);
 }elseif($type=="edit"){
 $this->db->where("id_barang",$id)->update("barang",$data);
 }
 }
 
 function barangById($id){
 return $this->db->where("id_barang",$id)->get("barang");
 }
 
 //Admin
 function getAdmin(){
  $this->datatables->select("id_akun,nama_akun,username,level")->from("akun")->add_column('aksi','<div class="btn-group"><a href="formAdmin/$1" class="btn btn-info">Edit</a> <button class="btn btn-danger" onclick="modalhapus(`admin`,`$1`)" data-toggle="modal" data-target="#modalhapus">Delete</button></div>','id_akun');
  return $this->datatables->generate();
 }
 
 function actAdmin($type,$id,$data){
 if($type=="tambah"){
 $this->db->insert("akun",$data);
 }elseif($type=="edit"){
 $this->db->where("id_akun",$id)->update("akun",$data);
 }
 }
 
 function adminById($id){
 return $this->db->where("id_akun",$id)->get("akun");
 }
 
 //setting
 function setting(){
  return $this->db->get("setting");
 }
 
 function actSetting($data){
  $this->db->empty_table("setting");
  $this->db->insert("setting",$data);
 }
 
 function hapusdata($type,$id){
  switch($type){
   case "booking_room":
    $this->db->where("id_booking_room",$id)->delete("booking_room");
   break;
   case "daftar_transaksi":
    $this->db->where("id_group_transaksi",$id)->delete("group_transaksi");
    $this->db->where("id_group_transaksi",$id)->delete("transaksi");
   break;
   case "keuangan":
   $this->db->where("id_keuangan",$id)->delete("keuangan");
   break;
   case "menu":
   $this->db->where("id_menu",$id)->delete("menu");
   break;
   case "room":
   $this->db->where("id_room",$id)->delete("room");
   break;
   case "barang":
   $this->db->where("id_barang",$id)->delete("barang");
   break;
   case "admin":
   $this->db->where("id_akun",$id)->delete("akun");
   break;
  }
 }
 
}